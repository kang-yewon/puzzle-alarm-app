"""
AppController: owns the main window, all screens, alarm manager, and navigation.
Acts as the application's single source of truth.
For mobile porting: replace tkinter-specific show/hide with the target framework's
navigation stack.
"""

import tkinter as tk
from typing import Literal

from .models import AlarmSettings
from . import storage, audio_manager
from .alarm_manager import AlarmManager

ScreenName = Literal["home", "settings", "ringing", "puzzle", "complete", "sound"]

WINDOW_W = 360
WINDOW_H = 720
BG = "#FFF0F5"


class AppController:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self._setup_window()
        self.settings: AlarmSettings = storage.load_settings()
        self._build_screens()
        self._alarm_manager = AlarmManager(on_alarm_trigger=self._on_alarm_trigger)
        self._alarm_manager.start(self.settings)
        self.show_screen("home")

    # ------------------------------------------------------------------
    # Window setup
    # ------------------------------------------------------------------

    def _setup_window(self) -> None:
        self.root.title("퍼즐 알람")
        self.root.geometry(f"{WINDOW_W}x{WINDOW_H}")
        self.root.resizable(False, False)
        self.root.configure(bg=BG)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        # Center on screen
        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x = (sw - WINDOW_W) // 2
        y = (sh - WINDOW_H) // 2
        self.root.geometry(f"{WINDOW_W}x{WINDOW_H}+{x}+{y}")

    # ------------------------------------------------------------------
    # Screen management
    # ------------------------------------------------------------------

    def _build_screens(self) -> None:
        from .screens.home_screen import HomeScreen
        from .screens.settings_screen import SettingsScreen
        from .screens.alarm_ringing_screen import AlarmRingingScreen
        from .screens.puzzle_screen import PuzzleScreen
        from .screens.complete_screen import CompleteScreen
        from .screens.sound_settings_screen import SoundSettingsScreen

        # All screens share the same grid cell; we raise the one we want.
        container = tk.Frame(self.root, bg=BG)
        container.pack(fill="both", expand=True)

        self._screens: dict[ScreenName, object] = {
            "home": HomeScreen(container, self),
            "settings": SettingsScreen(container, self),
            "ringing": AlarmRingingScreen(container, self),
            "puzzle": PuzzleScreen(container, self),
            "complete": CompleteScreen(container, self),
            "sound": SoundSettingsScreen(container, self),
        }

        for screen in self._screens.values():
            screen.place(relx=0, rely=0, relwidth=1, relheight=1)

        self._current: ScreenName | None = None

    def show_screen(self, name: ScreenName) -> None:
        screen = self._screens[name]
        screen.lift()
        screen.on_show()
        self._current = name

    # ------------------------------------------------------------------
    # Alarm events (called from background thread via after())
    # ------------------------------------------------------------------

    def _on_alarm_trigger(self) -> None:
        # Schedule on main thread — never touch Tk from background thread
        self.root.after(0, self._alarm_fire)

    def _alarm_fire(self) -> None:
        audio_manager.play_alarm(self.settings.sound_path)
        self.show_screen("ringing")

    def on_puzzles_complete(self) -> None:
        audio_manager.stop_alarm()
        self.show_screen("home")

    # ------------------------------------------------------------------
    # Settings persistence
    # ------------------------------------------------------------------

    def save_settings(self) -> None:
        storage.save_settings(self.settings)
        self._alarm_manager.update_settings(self.settings)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _on_close(self) -> None:
        self._alarm_manager.stop()
        audio_manager.stop_alarm()
        self.root.destroy()

    # ------------------------------------------------------------------
    # Dev helper: trigger alarm immediately (for testing)
    # ------------------------------------------------------------------

    def debug_trigger_alarm(self) -> None:
        self._alarm_fire()
