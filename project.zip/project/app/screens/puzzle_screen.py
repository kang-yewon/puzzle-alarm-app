"""
Puzzle screen: sequences N puzzles, manages the 15-second idle timer,
pauses alarm while on screen, resumes alarm if idle timer expires.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout

class PuzzleScreen(Screen):
    def __init__(self, **kwargs):
        super(PuzzleScreen, self).__init__(**kwargs)
        
        layout = BoxLayout(orientation='vertical', padding=30, spacing=15)
        
        layout.add_widget(Label(text="🔒 잠금 해제 미션", font_size='24sp', bold=True))
        layout.add_widget(Label(text="문제: 15 + 28 = ?", font_size='30sp'))
        
        # 글자를 타이핑할 수 있는 입력창
        self.answer_input = TextInput(hint_text="정답 숫자를 입력하세요", multiline=False, size_hint=(1, 0.15), font_size='18sp')
        layout.add_widget(self.answer_input)
        
        # 정답 확인 버튼
        btn_submit = Button(text="정답 확인", size_hint=(1, 0.2))
        btn_submit.bind(on_press=self.check_answer)
        layout.add_widget(btn_submit)
        
        self.add_widget(layout)

    def check_answer(self, instance):
        # 정답인 '43'을 입력하면 완료 화면으로 이동
        if self.answer_input.text == "43":
            self.manager.current = 'complete'
        else:
            self.answer_input.text = ""
            self.answer_input.hint_text = "❌ 틀렸습니다! 다시 생각해보세요."