"""
Base screen class — thin wrapper around tk.Frame.
For mobile porting: swap tk.Frame for the target framework's screen/view class.
"""

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Color, Rectangle

class BaseScreen(Screen):
    def __init__(self, **kwargs):
        super(BaseScreen, self).__init__(**kwargs)
        
        # 모든 화면에 공통으로 적용할 배경색을 지정할 수 있는 기본 클래스입니다.
        self.main_layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        self.add_widget(self.main_layout)
        """Called every time this screen is navigated to. Override as needed."""
