"""
Alarm ringing screen: shown when alarm fires.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout

class AlarmRingingScreen(Screen):
    def __init__(self, **kwargs):
        super(AlarmRingingScreen, self).__init__(**kwargs)
        
        layout = BoxLayout(orientation='vertical', padding=30, spacing=20)
        
        layout.add_widget(Label(text="🚨 알람이 울립니다! 🚨", font_size='32sp', bold=True, color=(1, 0, 0, 1)))
        layout.add_widget(Label(text="어서 일어나서 미션을 해결하세요!", font_size='18sp'))
        
        # 퍼즐을 풀어야만 알람을 끌 수 있도록 퍼즐 화면으로 유도하는 버튼
        btn_dismiss = Button(text="🧩 미션 풀고 알람 끄기", size_hint=(1, 0.2), background_color=(1, 0.3, 0.3, 1))
        btn_dismiss.bind(on_press=self.go_to_puzzle)
        layout.add_widget(btn_dismiss)
        
        self.add_widget(layout)

    def go_to_puzzle(self, instance):
        self.manager.current = 'puzzle'
