"""
Completion screen: shown for 3 seconds after all puzzles are solved.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout

class CompleteScreen(Screen):
    def __init__(self, **kwargs):
        super(CompleteScreen, self).__init__(**kwargs)
        
        layout = BoxLayout(orientation='vertical', padding=30, spacing=20)
        
        layout.add_widget(Label(text="🎉 미션 성공! 🎉", font_size='32sp', bold=True, color=(0, 1, 0, 1)))
        layout.add_widget(Label(text="알람이 정상적으로 종료되었습니다.\n오늘도 멋진 하루를 시작하세요!", font_size='18sp', halign='center'))
        
        # 메인 홈 화면으로 돌아가는 버튼
        btn_home = Button(text="확인 (홈으로 이동)", size_hint=(1, 0.2))
        btn_home.bind(on_press=self.go_to_home)
        layout.add_widget(btn_home)
        
        self.add_widget(layout)

    def go_to_home(self, instance):
        self.manager.current = 'home'