"""
Sound settings screen: select an alarm sound file.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout

class SoundSettingsScreen(Screen):
    def __init__(self, **kwargs):
        super(SoundSettingsScreen, self).__init__(**kwargs)
        
        layout = BoxLayout(orientation='vertical', padding=30, spacing=15)
        
        layout.add_widget(Label(text="🎵 소리 및 음량 설정", font_size='26sp', bold=True))
        
        # 소리 테스트 버튼 예시
        btn_test = Button(text="🔔 알람 소리 미리듣기", size_hint=(1, 0.2))
        layout.add_widget(btn_test)
        
        # 이전 설정 화면으로 돌아가기 버튼
        btn_back = Button(text="⬅️ 이전 화면으로", size_hint=(1, 0.2))
        btn_back.bind(on_press=self.go_to_settings)
        layout.add_widget(btn_back)
        
        self.add_widget(layout)

    def go_to_settings(self, instance):
        self.manager.current = 'settings'