"""
Home screen: displays alarm time, on/off toggle, and settings button.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout

class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super(HomeScreen, self).__init__(**kwargs)
        
        layout = BoxLayout(orientation='vertical', padding=30, spacing=20)
        
        # 타이틀
        layout.add_widget(Label(text="⏰ 꼬마 정원사 알람 앱", font_size='28sp', bold=True))
        layout.add_widget(Label(text="반갑습니다! 오늘도 좋은 하루 보내세요.", font_size='16sp'))
        
        # 버튼 1: 설정 화면으로 이동
        btn_settings = Button(text="⚙️ 알람 및 환경 설정", size_hint=(1, 0.2), font_size='18sp')
        btn_settings.bind(on_press=self.go_to_settings)
        layout.add_widget(btn_settings)
        
        # 버튼 2: 퍼즐 미리 풀어보기 (테스트용)
        btn_puzzle = Button(text="🧩 퍼즐 미션 테스트", size_hint=(1, 0.2), font_size='18sp')
        btn_puzzle.bind(on_press=self.go_to_puzzle)
        layout.add_widget(btn_puzzle)
        
        self.add_widget(layout)

    def go_to_settings(self, instance):
        self.manager.current = 'settings'

    def go_to_puzzle(self, instance):
        self.manager.current = 'puzzle'