from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout

class SettingsScreen(Screen):
    def __init__(self, **kwargs):
        super(SettingsScreen, self).__init__(**kwargs)
        
        layout = BoxLayout(orientation='vertical', padding=30, spacing=15)
        
        layout.add_widget(Label(text="⚙️ 환경 설정", font_size='26sp', bold=True))
        
        # 소리 설정 이동 버튼
        btn_sound = Button(text="🎵 알람 소리 및 음량 설정", size_hint=(1, 0.2))
        btn_sound.bind(on_press=self.go_to_sound)
        layout.add_widget(btn_sound)
        
        # 돌아가기 버튼
        btn_back = Button(text="🏠 홈으로 돌아가기", size_hint=(1, 0.2))
        btn_back.bind(on_press=self.go_to_home)
        layout.add_widget(btn_back)
        
        self.add_widget(layout)

    def go_to_sound(self, instance):
        self.manager.current = 'sound_settings'

    def go_to_home(self, instance):
        self.manager.current = 'home'