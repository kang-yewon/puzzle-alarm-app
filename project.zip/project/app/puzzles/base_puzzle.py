"""
Abstract base for all puzzle types.
Each puzzle is a self-contained Tkinter Frame.
For mobile porting: replace the tkinter.Frame base with the target framework's view.
"""

import tkinter as tk
from tkinter import ttk
from typing import Callable
from abc import ABC, abstractmethod

# Design tokens — change once to restyle everywhere
COLORS = {
    "bg": "#FFF0F5",
    "primary": "#B96EFF",
    "primary_dark": "#9B4FE8",
    "surface": "#FFFFFF",
    "text": "#2D2D2D",
    "text_secondary": "#888888",
    "input_bg": "#F8F0FF",
    "border": "#E8D5FF",
    "success": "#4CAF50",
    "error": "#FF5252",
    "timer_warning": "#FF9800",
}

FONTS = {
    "title": ("Pretendard", 18, "bold"),
    "body": ("Pretendard", 13),
    "small": ("Pretendard", 11),
    "large_number": ("Pretendard", 36, "bold"),
    "button": ("Pretendard", 14, "bold"),
}

# Fallback font names if Pretendard is not installed
_FALLBACK = "Helvetica"


def font(key: str) -> tuple:
    f = FONTS[key]
    return (f[0],) + f[1:]  # keep as-is; Tk ignores unknown families and falls back


class BasePuzzle(tk.Frame, ABC):
    """
    One puzzle instance.  on_success is called when the user solves it.
    The parent screen manages sequencing multiple puzzles.
    """

    def __init__(self, parent: tk.Widget, on_success: Callable[[], None]) -> None:
        super().__init__(parent, bg=COLORS["bg"])
        self.on_success = on_success
        self._build_ui()

    @abstractmethod
    def _build_ui(self) -> None:
        """Render puzzle-specific widgets."""

    def notify_activity(self) -> None:
        """Called by parent on any user interaction to reset idle timer."""
