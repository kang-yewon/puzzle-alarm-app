"""
Typing puzzle: type the displayed sentence exactly.
"""

import random
import tkinter as tk
from .base_puzzle import BasePuzzle, COLORS


_SENTENCES = [
    "오늘도 좋은 하루입니다.",
    "일어나서 하루를 시작하세요.",
    "좋은 아침이에요, 힘내세요!",
    "오늘 하루도 파이팅입니다.",
    "일어나야 할 시간이에요.",
    "새로운 하루가 시작되었습니다.",
    "건강한 하루 보내세요.",
    "일찍 일어나는 새가 먹이를 잡는다.",
    "지금 일어나면 하루가 달라집니다.",
    "알람을 끄고 기지개를 켜세요.",
]


def pick_sentence() -> str:
    return random.choice(_SENTENCES)


class TypingPuzzle(BasePuzzle):
    def _build_ui(self) -> None:
        self._target = pick_sentence()

        desc = tk.Label(
            self,
            text="아래 문장을 똑같이 입력하세요.",
            font=("Helvetica", 13),
            bg=COLORS["bg"],
            fg=COLORS["text_secondary"],
        )
        desc.pack(pady=(20, 8))

        target_frame = tk.Frame(
            self, bg=COLORS["surface"],
            highlightbackground=COLORS["border"], highlightthickness=1
        )
        target_frame.pack(fill="x", padx=30, pady=(0, 16))

        target_lbl = tk.Label(
            target_frame,
            text=self._target,
            font=("Helvetica", 16, "bold"),
            bg=COLORS["surface"],
            fg=COLORS["primary"],
            wraplength=280,
            justify="center",
            pady=14,
            padx=10,
        )
        target_lbl.pack()

        self._entry = tk.Entry(
            self,
            font=("Helvetica", 14),
            justify="center",
            bg=COLORS["input_bg"],
            fg=COLORS["text"],
            relief="flat",
            highlightthickness=2,
            highlightbackground=COLORS["border"],
            highlightcolor=COLORS["primary"],
        )
        self._entry.pack(fill="x", padx=30, ipadx=10, ipady=10)
        self._entry.bind("<Return>", lambda _e: self._check())
        self._entry.bind("<KeyPress>", lambda _e: self.notify_activity())
        self._entry.focus_set()

        hint = tk.Label(
            self,
            text="여기에 입력하세요.",
            font=("Helvetica", 11),
            bg=COLORS["bg"],
            fg=COLORS["text_secondary"],
        )
        hint.pack(pady=(2, 12))

        confirm_btn = tk.Button(
            self,
            text="확인",
            font=("Helvetica", 14, "bold"),
            bg=COLORS["primary"],
            fg="white",
            activebackground=COLORS["primary_dark"],
            activeforeground="white",
            relief="flat",
            cursor="hand2",
            command=self._check,
        )
        confirm_btn.pack(fill="x", padx=30, ipady=12)
        confirm_btn.bind("<ButtonPress-1>", lambda _e: self.notify_activity())

        self._feedback = tk.Label(
            self, text="", font=("Helvetica", 11),
            bg=COLORS["bg"], fg=COLORS["error"]
        )
        self._feedback.pack(pady=6)

    def _check(self) -> None:
        self.notify_activity()
        typed = self._entry.get()
        if typed == self._target:
            self._feedback.config(text="정답!", fg=COLORS["success"])
            self.after(400, self.on_success)
        else:
            self._feedback.config(text="똑같이 입력해 주세요.", fg=COLORS["error"])
            self._entry.delete(0, tk.END)
