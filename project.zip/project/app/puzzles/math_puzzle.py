"""
Math puzzle: simple but tricky arithmetic questions.
"""

import random
import tkinter as tk
from tkinter import messagebox
from .base_puzzle import BasePuzzle, COLORS, font


_TEMPLATES = [
    lambda: _make(random.randint(11, 19), "×", random.randint(2, 9),
                  "-", random.randint(1, 20)),
    lambda: _make(random.randint(2, 9), "×", random.randint(11, 19),
                  "+", random.randint(1, 20)),
    lambda: _make(random.randint(10, 30), "+", random.randint(10, 30),
                  "×", random.randint(2, 5)),   # order-of-operations trap
    lambda: _make_div(),
    lambda: _make(random.randint(50, 99), "-", random.randint(11, 49),
                  "+", random.randint(1, 15)),
]


def _make(a, op1, b, op2, c):
    if op1 == "×" and op2 == "+":
        answer = a * b + c
    elif op1 == "×" and op2 == "-":
        answer = a * b - c
    elif op1 == "+" and op2 == "×":
        answer = a + b * c   # order of operations trap
    elif op1 == "-" and op2 == "+":
        answer = a - b + c
    else:
        answer = a + b - c
    question = f"{a} {op1} {b} {op2} {c} = ?"
    return question, answer


def _make_div():
    b = random.randint(2, 9)
    a = b * random.randint(3, 12)
    c = random.randint(1, 10)
    answer = a // b + c
    question = f"{a} ÷ {b} + {c} = ?"
    return question, answer


def generate_question() -> tuple[str, int]:
    template = random.choice(_TEMPLATES)
    return template()


class MathPuzzle(BasePuzzle):
    def _build_ui(self) -> None:
        self._question, self._answer = generate_question()

        self.columnconfigure(0, weight=1)

        question_lbl = tk.Label(
            self,
            text=self._question,
            font=("Helvetica", 28, "bold"),
            bg=COLORS["bg"],
            fg=COLORS["text"],
        )
        question_lbl.grid(row=0, column=0, pady=(30, 20))

        self._entry = tk.Entry(
            self,
            font=("Helvetica", 16),
            justify="center",
            bg=COLORS["input_bg"],
            fg=COLORS["text"],
            relief="flat",
            highlightthickness=2,
            highlightbackground=COLORS["border"],
            highlightcolor=COLORS["primary"],
        )
        self._entry.grid(row=1, column=0, ipadx=20, ipady=10, padx=40, sticky="ew")
        self._entry.bind("<Return>", lambda _e: self._check())
        self._entry.bind("<KeyPress>", lambda _e: self.notify_activity())
        self._entry.focus_set()

        hint = tk.Label(
            self,
            text="정답 입력",
            font=("Helvetica", 11),
            bg=COLORS["bg"],
            fg=COLORS["text_secondary"],
        )
        hint.grid(row=2, column=0, pady=(2, 16))

        confirm_btn = tk.Button(
            self,
            text="확인",
            font=("Helvetica", 14, "bold"),
            bg=COLORS["primary"],
            fg="white",
            activebackground=COLORS["primary_dark"],
            activeforeground="white",
            relief="flat",
            cursor="hand2",
            command=self._check,
        )
        confirm_btn.grid(row=3, column=0, padx=40, ipady=12, sticky="ew")
        confirm_btn.bind("<ButtonPress-1>", lambda _e: self.notify_activity())

        self._feedback = tk.Label(
            self, text="", font=("Helvetica", 11),
            bg=COLORS["bg"], fg=COLORS["error"]
        )
        self._feedback.grid(row=4, column=0, pady=6)

    def _check(self) -> None:
        self.notify_activity()
        raw = self._entry.get().strip()
        try:
            value = int(raw)
        except ValueError:
            self._feedback.config(text="숫자를 입력해 주세요.", fg=COLORS["error"])
            return
        if value == self._answer:
            self._feedback.config(text="정답!", fg=COLORS["success"])
            self.after(400, self.on_success)
        else:
            self._feedback.config(text="틀렸어요. 다시 시도하세요.", fg=COLORS["error"])
            self._entry.delete(0, tk.END)
