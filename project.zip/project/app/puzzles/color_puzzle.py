"""
Color distinction puzzle: find the one slightly-different tile in a grid.
Uses a single Canvas for the grid so tile colors render reliably on all platforms.
"""

import random
import colorsys
import tkinter as tk
from .base_puzzle import BasePuzzle, COLORS


_BASE_HUES = [
    (0.92, "핑크"),
    (0.60, "파랑"),
    (0.33, "초록"),
    (0.08, "주황"),
    (0.70, "보라"),
    (0.50, "하늘"),
    (0.00, "빨강"),
    (0.14, "노랑"),
]

_GRID_COLS = 4
_GRID_ROWS = 4
_TILE = 58   # pixels
_GAP = 5


def _hsv_to_hex(h: float, s: float, v: float) -> str:
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, max(0.0, min(1.0, s)), max(0.0, min(1.0, v)))
    return f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"


def _generate_puzzle():
    """
    Returns (base_hex, odd_hex, odd_row, odd_col, color_name).
    The odd tile differs only in one HSV dimension by a very small amount —
    subtle enough to require careful looking.
    """
    hue, name = random.choice(_BASE_HUES)
    sat = random.uniform(0.50, 0.70)
    val = random.uniform(0.78, 0.90)

    # Pick ONE dimension to shift, keep the shift tiny
    mode = random.choice(["hue", "val", "sat"])
    if mode == "hue":
        delta = random.choice([-1, 1]) * random.uniform(0.007, 0.014)
        odd_hex = _hsv_to_hex(hue + delta, sat, val)
    elif mode == "val":
        delta = random.choice([-1, 1]) * random.uniform(0.025, 0.045)
        odd_hex = _hsv_to_hex(hue, sat, val + delta)
    else:
        delta = random.choice([-1, 1]) * random.uniform(0.04, 0.08)
        odd_hex = _hsv_to_hex(hue, sat + delta, val)

    base_hex = _hsv_to_hex(hue, sat, val)
    odd_row = random.randint(0, _GRID_ROWS - 1)
    odd_col = random.randint(0, _GRID_COLS - 1)
    return base_hex, odd_hex, odd_row, odd_col, name


class ColorPuzzle(BasePuzzle):
    def _build_ui(self) -> None:
        self._base_hex, self._odd_hex, self._odd_row, self._odd_col, name = _generate_puzzle()
        self._answered = False

        desc = tk.Label(
            self,
            text="다른 색 하나를 찾아 터치하세요.",
            font=("Helvetica", 14, "bold"),
            bg=COLORS["bg"],
            fg=COLORS["text"],
        )
        desc.pack(pady=(16, 10))

        total_w = _GRID_COLS * _TILE + (_GRID_COLS + 1) * _GAP
        total_h = _GRID_ROWS * _TILE + (_GRID_ROWS + 1) * _GAP

        self._canvas = tk.Canvas(
            self,
            width=total_w,
            height=total_h,
            bg=COLORS["bg"],
            highlightthickness=0,
            cursor="hand2",
        )
        self._canvas.pack(pady=4)
        self._canvas.bind("<Button-1>", self._on_canvas_click)

        self._draw_grid()

        self._feedback = tk.Label(
            self, text="",
            font=("Helvetica", 11),
            bg=COLORS["bg"],
            fg=COLORS["error"],
        )
        self._feedback.pack(pady=6)

    def _draw_grid(self) -> None:
        c = self._canvas
        c.delete("all")
        self._tile_rects: list[list[int]] = []   # tag ids
        for r in range(_GRID_ROWS):
            row_ids = []
            for col in range(_GRID_COLS):
                color = self._odd_hex if (r == self._odd_row and col == self._odd_col) \
                        else self._base_hex
                x1 = _GAP + col * (_TILE + _GAP)
                y1 = _GAP + r * (_TILE + _GAP)
                x2 = x1 + _TILE
                y2 = y1 + _TILE
                item = c.create_rectangle(x1, y1, x2, y2, fill=color, outline="", tags="tile")
                row_ids.append(item)
            self._tile_rects.append(row_ids)

    def _on_canvas_click(self, event: tk.Event) -> None:
        if self._answered:
            return
        self.notify_activity()
        col = (event.x - _GAP) // (_TILE + _GAP)
        row = (event.y - _GAP) // (_TILE + _GAP)
        if not (0 <= row < _GRID_ROWS and 0 <= col < _GRID_COLS):
            return
        # Verify click is inside the tile (not in the gap)
        x1 = _GAP + col * (_TILE + _GAP)
        y1 = _GAP + row * (_TILE + _GAP)
        if not (x1 <= event.x <= x1 + _TILE and y1 <= event.y <= y1 + _TILE):
            return
        if row == self._odd_row and col == self._odd_col:
            self._answered = True
            # Highlight the correct tile
            item = self._tile_rects[row][col]
            self._canvas.itemconfig(item, outline="#FFFFFF", width=3)
            self._feedback.config(text="정답!", fg=COLORS["success"])
            self.after(500, self.on_success)
        else:
            self._feedback.config(text="틀렸어요. 다시 찾아보세요.", fg=COLORS["error"])
