"""
Audio playback abstraction layer.
Swap this module for a mobile port (e.g. Android MediaPlayer).
"""

import threading
import os

_pygame_available = False
_mixer_initialized = False

try:
    import pygame
    _pygame_available = True
except ImportError:
    pass

_playing = False
_channel: "pygame.mixer.Channel | None" = None
_sound: "pygame.mixer.Sound | None" = None   # module-level ref prevents GC
_loop_thread: threading.Thread | None = None
_stop_event = threading.Event()
_current_sound_path: str = ""
_using_channel = False   # True when pygame channel is active, False when beep thread


def _init_mixer() -> bool:
    global _mixer_initialized
    if _mixer_initialized:
        return True
    if not _pygame_available:
        return False
    try:
        pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
        _mixer_initialized = True
        return True
    except Exception:
        return False


def _beep_loop(stop_event: threading.Event) -> None:
    import sys
    while not stop_event.is_set():
        try:
            if sys.platform == "win32":
                import winsound
                winsound.Beep(880, 400)
            else:
                print("\a", end="", flush=True)
        except Exception:
            pass
        stop_event.wait(0.8)


def _make_beep_sound() -> "pygame.mixer.Sound | None":
    try:
        import numpy as np
        sample_rate = 22050
        duration = 0.6
        t = np.linspace(0, duration, int(sample_rate * duration), False)
        wave = (np.sin(2 * np.pi * 880 * t) * 28000).astype(np.int16)
        stereo = np.column_stack([wave, wave])
        return pygame.sndarray.make_sound(stereo)
    except Exception:
        return None


def play_alarm(sound_path: str = "") -> None:
    global _playing, _channel, _sound, _loop_thread, _stop_event
    global _current_sound_path, _using_channel
    if _playing:
        return
    _playing = True
    _stop_event.clear()
    _current_sound_path = sound_path

    if _init_mixer():
        # Try loading user-provided file
        if sound_path and os.path.isfile(sound_path):
            try:
                _sound = pygame.mixer.Sound(sound_path)
                _channel = _sound.play(-1)
                _using_channel = True
                return
            except Exception:
                pass
        # Try generating a beep via numpy
        beep = _make_beep_sound()
        if beep is not None:
            _sound = beep
            _channel = _sound.play(-1)
            _using_channel = True
            return

    # Fallback: threaded system beep
    _using_channel = False
    _loop_thread = threading.Thread(target=_beep_loop, args=(_stop_event,), daemon=True)
    _loop_thread.start()


def pause_alarm() -> None:
    if not _playing:
        return
    if _using_channel and _channel is not None:
        try:
            _channel.pause()
        except Exception:
            pass
    else:
        _stop_event.set()


def resume_alarm() -> None:
    global _loop_thread, _stop_event
    if not _playing:
        play_alarm(_current_sound_path)
        return
    if _using_channel and _channel is not None:
        try:
            _channel.unpause()
            return
        except Exception:
            pass
    # Fallback path: restart beep thread
    _stop_event.clear()
    _loop_thread = threading.Thread(target=_beep_loop, args=(_stop_event,), daemon=True)
    _loop_thread.start()


def stop_alarm() -> None:
    global _playing, _channel, _sound, _loop_thread, _using_channel
    _playing = False
    _stop_event.set()
    if _using_channel and _channel is not None:
        try:
            _channel.stop()
        except Exception:
            pass
    if _sound is not None:
        try:
            _sound.stop()
        except Exception:
            pass
    _channel = None
    _sound = None
    _loop_thread = None
    _using_channel = False
