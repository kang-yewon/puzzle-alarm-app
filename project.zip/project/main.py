"""
Puzzle Alarm App — entry point.

Run:
    python main.py

Optional: pass --debug to trigger the alarm immediately on launch
(useful during development).

To convert to APK later:
    - Replace tkinter with Kivy or BeeWare.
    - The app/app_controller.py, app/models.py, app/storage.py,
      app/alarm_manager.py, and app/puzzles/* files require minimal changes.
    - Only app/screens/* and app/audio_manager.py need UI-layer rewrites.
"""
import os
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager

# 우리가 새로 바꾼 8개의 화면 파일들을 모두 가져옵니다.
from app.screens.home_screen import HomeScreen
from app.screens.settings_screen import SettingsScreen
from app.screens.sound_settings_screen import SoundSettingsScreen
from app.screens.alarm_ringing_screen import AlarmRingingScreen
from app.screens.puzzle_screen import PuzzleScreen
from app.screens.complete_screen import CompleteScreen
# base_screen은 배경용이라 여기에 등록하지 않고, _init_은 빈 파일이라 제외합니다.

class AlarmApp(App):
    def build(self):
        # 화면들을 관리하는 '매니저'를 만듭니다.
        sm = ScreenManager()
        
        # 6개의 핵심 화면들을 매니저에 차곡차곡 등록합니다.
        sm.add_widget(HomeScreen(name='home'))
        sm.add_widget(SettingsScreen(name='settings'))
        sm.add_widget(SoundSettingsScreen(name='sound_settings'))
        sm.add_widget(AlarmRingingScreen(name='alarm_ringing'))
        sm.add_widget(PuzzleScreen(name='puzzle'))
        sm.add_widget(CompleteScreen(name='complete'))
        
        return sm

if __name__ == '__main__':
    AlarmApp().run()